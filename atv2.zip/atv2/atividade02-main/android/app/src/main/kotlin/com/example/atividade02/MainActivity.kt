package com.example.atividade02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
